$(".page-id-6, body").vegas({
    timer: false,
    delay: 6000,
    transitionDuration: 3000,
    slides: [
        { src: "wp-content/themes/KC%20Features/assets/images/backgrounds/background.jpg" },
        { src: "wp-content/themes/KC%20Features/assets/images/backgrounds/background1.jpg" },
        { src: "wp-content/themes/KC%20Features/assets/images/backgrounds/background2.jpg" },
        { src: "wp-content/themes/KC%20Features/assets/images/backgrounds/background3.jpg" }
    ]
});